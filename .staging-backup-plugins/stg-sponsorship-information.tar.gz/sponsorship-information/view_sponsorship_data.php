<?php
global $wpdb;
$table = 'aal10_sponsorship_master';

if($_REQUEST['action']=='view')
{
  $headline = 'View Details';
  
  if($_REQUEST['action']=='view')
  { 
    $sponsor_id = $_REQUEST['id'];
    $row_pp = $wpdb->get_row("SELECT * FROM ".$table." where sponsorhip_id='".$sponsor_id."'" );
    if(count($row_pp) > 0)
    {
      $sponsorhip_type = $row_pp->sponsorhip_type;
      $company_name = $row_pp->company_name;
      $company_address = $row_pp->company_address;
      $company_type = $row_pp->company_type;
      $contact_person = $row_pp->contact_person;
      $company_phone = $row_pp->company_phone;
      $first_name = $row_pp->first_name;
      $last_name = $row_pp->last_name;
      $billing_address = $row_pp->billing_address;
      $billing_city = $row_pp->billing_city;
      $billing_state = $row_pp->billing_state;
      $billing_postal_code = $row_pp->billing_postal_code;
      $phone_number = $row_pp->phone_number;
      $email_address = $row_pp->email_address;
      $sponsorship_information = $row_pp->sponsorship_information;
      $amount_deduct = $row_pp->amount_deduct;
      $card_name = $row_pp->card_name;
      $card_type = $row_pp->card_type;
      $date_added = $row_pp->date_added;

    }
    
  }
?>

<style type="text/css">
h2  { color: #664fa0!important; border-top: 0px solid #c2c2c2;
    border-bottom: 1px solid #999999;
    padding: 10px 0;}
.border{border-bottom:1px solid #ccc;}

/*
td { font-size: 14px; }
table.border, table.border td, table.border th {
  border-collapse:collapse;
  border:1px solid #666;
}
*/
</style>

<div class="wrap">
  <h2>
    <?php  _e($headline,'AAREP-PHL'); ?><a class="add-new-h2" href="admin.php?page=sponsor_info">Back</a></h2>
    <div class="form">
       <table width="100%" border="0" cellspacing="0" cellpadding="0" style="border: 1px solid #c2c2c2;padding: 10px;">
      <tr>
        <td align="left" valign="top"><h2>Billing Information</h2></td>
      </tr>
      <tr>
        <td align="left" valign="top"><table width="100%" border="0" cellpadding="5" cellspacing="0" class="border">
        <tr>
            <th width="170" align="left" valign="top">First Name:</th>
            <td colspan="5" align="left" valign="top"><?php echo $first_name; ?></td>
            </tr>
          <tr>
            <th align="left" valign="top">Last Name:</th>
            <td colspan="5" align="left" valign="top"><?php echo $last_name; ?></td>
            </tr>
            <th align="left" valign="top">E-mail Address:</th>
            <td colspan="5" align="left" valign="top"><?php echo $email_address; ?></td>
            </tr>  
          <th align="left" valign="top">Billing Address:</th>
            <td colspan="5" align="left" valign="top"><?php echo $billing_address; ?></td>
            </tr>
            <th align="left" valign="top">City:</th>
            <td colspan="5" align="left" valign="top"><?php echo $billing_city; ?></td>
            </tr>
            <th align="left" valign="top">State:</th>
            <td colspan="5" align="left" valign="top"><?php echo $billing_state; ?></td>
            </tr>
            <th align="left" valign="top">Postal Code:</th>
            <td colspan="5" align="left" valign="top"><?php echo $billing_postal_code; ?></td>
            </tr>   
        </table></td>
      </tr>
      <tr>
        <td align="left" valign="top"><h2>Sponsorship Packages</h2></td>
      </tr>
      <tr>
        <td align="left" valign="top"><table width="100%" border="0" cellpadding="5" cellspacing="0" class="border">
        <tr>
            <th width="170" align="left" valign="top">Sponsorship Type:</th>
            <td colspan="5" align="left" valign="top"><?php echo $sponsorhip_type; ?></td>
            </tr>
          <tr>
            <th align="left" valign="top">Amount:</th>
            <td colspan="5" align="left" valign="top"><?php echo number_format($amount_deduct); ?></td>
            </tr> 
        </table></td>
      </tr>

      <tr>
        <td align="left" valign="top"><h2>Payment Information</h2></td>
      </tr>
      <tr>
        <td align="left" valign="top"><table width="100%" border="0" cellpadding="5" cellspacing="0" class="border">
        <tr>
            <th width="170" align="left" valign="top">Name on Card:</th>
            <td colspan="5" align="left" valign="top"><?php echo $card_name; ?></td>
            </tr>
          <tr>
            <th align="left" valign="top">Card Type:</th>
            <td colspan="5" align="left" valign="top"><?php echo $card_type; ?></td>
            </tr>   
        </table></td>
      </tr>
      <tr>
        <td align="left" valign="top"><h2>Date Submission</h2></td>
      </tr>
      <tr>
        <td align="left" valign="top"><table width="100%" border="0" cellpadding="5" cellspacing="0" class="border">
          <tr>
            <th width="170" align="left" valign="top">Date:</th>
            <td colspan="5" align="left" valign="top"><?php echo date('m-d-Y', strtotime($date_added)); ?></td>
            </tr>
        </table></td>
      </tr>
    </table>    
  </div>
</div>
<?php 
}

?>
<script type="text/javascript">
var home_url = '<?php echo PP_PLUGIN_URL;?>';
</script>