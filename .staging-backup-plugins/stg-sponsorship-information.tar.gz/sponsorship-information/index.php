<?php
/*
   Plugin Name: Sponsorship Application
   Plugin URI: http://apexglobalsolutions.com	
   Description: Used for display list of data.
   Version: 1.0
   Author: Apex Global solutions
   Author URI: http://apexglobalsolutions.com
*/
if ( ! defined( 'ABSPATH' ) ) { 
	exit; // Exit if accessed directly
}
if ( ! defined('PP_PLUGIN_BASENAME') )
	define('PP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
if ( ! defined('PP_PLUGIN_NAME') )
	define( 'PP_PLUGIN_NAME', trim( dirname(PP_PLUGIN_BASENAME ), '/' ) );
if ( ! defined( 'PP_PLUGIN_DIR' ) )
	define( 'PP_PLUGIN_DIR', WP_PLUGIN_DIR . '/' . PP_PLUGIN_NAME );
if ( ! defined( 'PP_PLUGIN_URL' ) )
	define( 'PP_PLUGIN_URL', WP_PLUGIN_URL . '/' . PP_PLUGIN_NAME );

	
add_action( 'admin_menu', 'contact_menu_items_donation');

function contact_menu_items_donation() {
	add_menu_page( "Sponsorship Information", "Sponsorship Information", 'manage_options', "sponsor_info",'application_class_data_sponsorship', '' ,30);
	add_submenu_page("null",'Sponsorship Information','Sponsorship Information','manage_options','view_application_sponsorship','view_sponsorship_information');
}
function application_class_data_sponsorship(){
	global $wpdb;
	include 'sponsorship_listing.php';
	include 'view_sponsorship_data.php';
}
function view_sponsorship_information(){
	global $wpdb;
	include 'view_sponsorship_data.php';
}

add_action("admin_init","sponsorship_admin_enquque_scripts_information");

function sponsorship_admin_enquque_scripts_information(){
    wp_enqueue_script('ui-sortable');
	 wp_enqueue_style('pp_custom', PP_PLUGIN_URL . '/assets/css/custom.css', false,null);
}
?>