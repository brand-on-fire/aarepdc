<?php
/*
   Plugin Name: Event Information
   Plugin URI: http://apexglobalsolutions.com	
   Description: Used for display list of data.
   Version: 1.0
   Author: Apex Global solutions
   Author URI: http://apexglobalsolutions.com
*/
if ( ! defined( 'ABSPATH' ) ) { 
	exit; // Exit if accessed directly
}
if ( ! defined('PP_PLUGIN_BASENAME') )
	define('PP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
if ( ! defined('PP_PLUGIN_NAME') )
	define( 'PP_PLUGIN_NAME', trim( dirname(PP_PLUGIN_BASENAME ), '/' ) );
if ( ! defined( 'PP_PLUGIN_DIR' ) )
	define( 'PP_PLUGIN_DIR', WP_PLUGIN_DIR . '/' . PP_PLUGIN_NAME );
if ( ! defined( 'PP_PLUGIN_URL' ) )
	define( 'PP_PLUGIN_URL', WP_PLUGIN_URL . '/' . PP_PLUGIN_NAME );

	
add_action( 'admin_menu', 'event_menu_items');

function event_menu_items() {
	add_menu_page( "Event Information", "Event Information", 'manage_options', "event_class_data_info",'event_class_data', '' ,30);
	add_submenu_page("null",'Event Information','Event Information','manage_options','view_event_information','view_event_class_data');
}
function event_class_data(){
	global $wpdb;
	include 'event_listing.php';
	include 'view_event_data.php';
}
function view_event_class_data(){
	global $wpdb;
	include 'view_event_data.php';
}

add_action("admin_init","event_admin_enquque_scripts_information");

function event_admin_enquque_scripts_information(){
    wp_enqueue_script('ui-sortable');
	 wp_enqueue_style('pp_custom', PP_PLUGIN_URL . '/assets/css/custom.css', false,null);
}
?>