<?php
/*
   Plugin Name: Membership Application
   Plugin URI: http://apexglobalsolutions.com	
   Description: Used for display list of data.
   Version: 1.0
   Author: Apex Global solutions
   Author URI: http://apexglobalsolutions.com
*/
if ( ! defined( 'ABSPATH' ) ) { 
	exit; // Exit if accessed directly
}
if ( ! defined('PP_PLUGIN_BASENAME') )
	define('PP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
if ( ! defined('PP_PLUGIN_NAME') )
	define( 'PP_PLUGIN_NAME', trim( dirname(PP_PLUGIN_BASENAME ), '/' ) );
if ( ! defined( 'PP_PLUGIN_DIR' ) )
	define( 'PP_PLUGIN_DIR', WP_PLUGIN_DIR . '/' . PP_PLUGIN_NAME );
if ( ! defined( 'PP_PLUGIN_URL' ) )
	define( 'PP_PLUGIN_URL', WP_PLUGIN_URL . '/' . PP_PLUGIN_NAME );

	
add_action( 'admin_menu', 'membership_menu_items_data');

function membership_menu_items_data() {
	add_menu_page( "Membership Information", "Membership Information", 'manage_options', "membership_info",'application_class_data_membership', '' ,30);
	add_submenu_page("null",'Membership Information','Membership Information','manage_options','view_application_membership','view_membership_information');
}
function application_class_data_membership(){
	global $wpdb;
	include 'membership_listing.php';
	include 'view_membership_data.php';
}
function view_membership_information(){
	global $wpdb;
	include 'view_membership_data.php';
}

add_action("admin_init","membership_admin_enquque_scripts_information");

function membership_admin_enquque_scripts_information(){
    wp_enqueue_script('ui-sortable');
	 wp_enqueue_style('pp_custom', PP_PLUGIN_URL . '/assets/css/custom.css', false,null);
}
?>